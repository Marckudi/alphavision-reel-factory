#!/usr/bin/env node
/**
 * AlphaVision · Fábrica de Reels
 * Uso: node render.mjs <spec.json>
 * Pipeline del documento maestro §8:
 *   HTML+CSS keyframes → Playwright recordVideo (WebM) → ffmpeg H.264 60fps CRF16
 *   → música aura (Python numpy) → merge con fade-in 0.4s / fade-out 1.5s
 * Si SUPABASE_URL + SUPABASE_SERVICE_KEY están definidos, sube el MP4 al bucket 'reels'
 * y actualiza content_calendar. Si N8N_CALLBACK_URL está definido, avisa a n8n.
 */
import { chromium } from 'playwright';
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const spec = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));

const OUT_DIR = process.env.OUT_DIR || path.join(ROOT, 'out');
const TMP = path.join(ROOT, 'tmp');
// Limpieza obligatoria: WebM viejos rompen el pipeline (doc §8)
fs.rmSync(TMP, { recursive: true, force: true });
fs.mkdirSync(TMP, { recursive: true });
fs.mkdirSync(OUT_DIR, { recursive: true });

// ---------- 1. Construir HTML desde la plantilla ----------
const template = fs.readFileSync(path.join(ROOT, 'templates', `${spec.template || 'listicle'}.html`), 'utf8');

function itemHTML(it, idx, delay) {
  const style = `class="item rise" style="animation-delay:${delay}s"`;
  if (it.type === 'cross') {
    return `<div ${style}><div class="icon" style="color:var(--red)">✕</div><div class="body"><div class="t strike">${it.text}</div>${it.fix ? `<div class="fix">→ ${it.fix}</div>` : ''}</div></div>`;
  }
  if (it.type === 'check') {
    return `<div ${style}><div class="icon" style="color:var(--green)">✓</div><div class="body"><div class="t">${it.text}</div>${it.desc ? `<div class="d">${it.desc}</div>` : ''}</div></div>`;
  }
  return `<div ${style}><div class="num">${String(idx + 1).padStart(2, '0')}</div><div class="body"><div class="t">${it.text}</div>${it.desc ? `<div class="d">${it.desc}</div>` : ''}</div></div>`;
}

let html;
if ((spec.template || 'listicle') === 'listicle') {
  const STAGGER = spec.stagger ?? 1.2;
  const firstItemAt = 1.4;
  const itemsHTML = spec.items.map((it, i) => itemHTML(it, i, firstItemAt + i * STAGGER)).join('\n');
  const ctaDelay = firstItemAt + spec.items.length * STAGGER + 0.4;
  var duration = spec.duration ?? Math.ceil(ctaDelay + 3.5);
  const hook = spec.hook_accent
    ? spec.hook.replace(spec.hook_accent, `<span class="accent">${spec.hook_accent}</span>`)
    : spec.hook;
  html = template
    .replaceAll('{{KICKER}}', spec.kicker || 'SISTEMA MRA')
    .replaceAll('{{HOOK}}', hook)
    .replaceAll('{{SUB}}', spec.sub || '')
    .replaceAll('{{ITEMS}}', itemsHTML)
    .replaceAll('{{CTA}}', spec.cta || '7 días gratis · alphavisionai.es')
    .replaceAll('{{CTA_DELAY}}', String(ctaDelay));
} else {
  // Plantillas genéricas (pov-origen, etc.): sustituye {{CLAVE}} desde spec.vars
  var duration = spec.duration ?? 11;
  html = template.replaceAll('{{KICKER}}', spec.kicker || 'ORIGEN');
  for (const [k, v] of Object.entries(spec.vars || {})) {
    html = html.replaceAll(`{{${k}}}`, String(v));
  }
}

const htmlPath = path.join(TMP, `${spec.slug}.html`);
fs.writeFileSync(htmlPath, html);

// ---------- 2. Grabar con Playwright ----------
console.log(`▸ Grabando ${spec.slug} (${duration}s)...`);
const browser = await chromium.launch();
const ctx = await browser.newContext({
  viewport: { width: 1080, height: 1920 },
  recordVideo: { dir: TMP, size: { width: 1080, height: 1920 } },
});
const page = await ctx.newPage();
await page.goto('file://' + htmlPath);
// las fuentes de Google necesitan un instante; el CSS está en assets/
await page.waitForTimeout(600);
await page.waitForTimeout(duration * 1000);
await ctx.close();
await browser.close();

const webm = fs.readdirSync(TMP).find(f => f.endsWith('.webm'));
if (!webm) throw new Error('Playwright no generó WebM');

// ---------- 3. Música aura ----------
const wav = path.join(TMP, `${spec.slug}.wav`);
if (spec.music !== 'none') {
  execSync(`python3 ${path.join(__dirname, 'music_aura.py')} ${duration + 0.6} ${wav}`, { stdio: 'inherit' });
}

// ---------- 4. Encode + merge ----------
const mp4 = path.join(OUT_DIR, `${spec.slug}.mp4`);
const fadeOutStart = Math.max(0, duration - 1.5);
if (spec.music !== 'none') {
  execSync(
    `ffmpeg -y -i "${path.join(TMP, webm)}" -i "${wav}" ` +
    `-ss 0.6 -r 60 -c:v libx264 -crf 16 -pix_fmt yuv420p -movflags +faststart ` +
    `-af "afade=t=in:d=0.4,afade=t=out:st=${fadeOutStart}:d=1.5" -c:a aac -b:a 192k -shortest "${mp4}"`,
    { stdio: 'inherit' }
  );
} else {
  execSync(
    `ffmpeg -y -i "${path.join(TMP, webm)}" -ss 0.6 -r 60 -c:v libx264 -crf 16 -pix_fmt yuv420p -movflags +faststart -an "${mp4}"`,
    { stdio: 'inherit' }
  );
}
console.log(`✔ Reel listo: ${mp4}`);

// ---------- 5. Subir a Supabase Storage + actualizar calendario ----------
const SB_URL = process.env.SUPABASE_URL, SB_KEY = process.env.SUPABASE_SERVICE_KEY;
let publicUrl = null;
if (SB_URL && SB_KEY) {
  const body = fs.readFileSync(mp4);
  const objPath = `reels/${spec.slug}.mp4`;
  const up = await fetch(`${SB_URL}/storage/v1/object/${objPath}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${SB_KEY}`, 'Content-Type': 'video/mp4', 'x-upsert': 'true' },
    body,
  });
  if (!up.ok) throw new Error(`Supabase upload: ${up.status} ${await up.text()}`);
  publicUrl = `${SB_URL}/storage/v1/object/public/${objPath}`;
  console.log(`✔ Subido: ${publicUrl}`);

  if (spec.calendar_id) {
    await fetch(`${SB_URL}/rest/v1/content_calendar?id=eq.${spec.calendar_id}`, {
      method: 'PATCH',
      headers: { apikey: SB_KEY, Authorization: `Bearer ${SB_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ video_url: publicUrl, needs_rerender: false }),
    });
    console.log('✔ content_calendar actualizado');
  }
}

// ---------- 6. Avisar a n8n (reanuda el workflow en el nodo Wait) ----------
if (process.env.N8N_CALLBACK_URL) {
  await fetch(process.env.N8N_CALLBACK_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ slug: spec.slug, video_url: publicUrl, calendar_id: spec.calendar_id ?? null, status: 'rendered' }),
  });
  console.log('✔ Callback a n8n enviado');
}
