#!/usr/bin/env python3
"""AlphaVision · Música 'entrepreneur aura' (estilo WYHB) · 100% original, sin copyright.
Uso: python3 music_aura.py <duracion_segundos> <salida.wav>"""
import sys, wave
import numpy as np

SR = 44100
BPM = 130
BEAT = 60 / BPM

def env(n, a=0.005, d=0.15):
    e = np.ones(n)
    na, nd = min(int(a*SR), n), min(int(d*SR), n)
    if na: e[:na] = np.linspace(0, 1, na)
    if nd: e[-nd:] *= np.linspace(1, 0, nd)
    return e

def note(freq, dur, kind="saw"):
    t = np.arange(int(dur*SR)) / SR
    if kind == "saw":
        s = 2*(t*freq % 1) - 1
    elif kind == "pluck":
        s = np.sign(np.sin(2*np.pi*freq*t)) * np.exp(-t*14)
    else:
        s = np.sin(2*np.pi*freq*t)
    return s * env(len(s))

def build(duration):
    n = int(duration*SR)
    mix = np.zeros(n)
    # Escala Am — sonido dark electronic
    A2, C3, E3, A3, C4, E4, G4, A4 = 110.0, 130.81, 164.81, 220.0, 261.63, 329.63, 392.0, 440.0

    # 1) Arpeggio pluck 16th notes con auto-filter (firma WYHB)
    arp = [A3, C4, E4, A4, E4, C4, G4, E4]
    step = BEAT/4
    i, pos = 0, 0.0
    while pos + step < duration:
        s = note(arp[i % len(arp)], step*0.9, "pluck") * 0.22
        # auto-filter: modula el brillo con LFO lento
        lfo = 0.6 + 0.4*np.sin(2*np.pi*0.15*pos)
        a = int(pos*SR); e = min(a+len(s), n)
        mix[a:e] += s[:e-a] * lfo
        i += 1; pos += step

    # 2) Kick 4-on-the-floor con pitch drop
    pos = 0.0
    while pos < duration:
        t = np.arange(int(0.16*SR)) / SR
        f = 120*np.exp(-t*28) + 42
        k = np.sin(2*np.pi*np.cumsum(f)/SR) * np.exp(-t*17) * 0.9
        a = int(pos*SR); e = min(a+len(k), n)
        mix[a:e] += k[:e-a]; pos += BEAT

    # 3) 808 sub bass con tanh
    prog = [(A2, 4), (C3, 4), (A2, 4), (E3, 4)]
    pos = 0.0
    while pos < duration:
        for f, beats in prog:
            d = beats*BEAT
            if pos >= duration: break
            t = np.arange(int(min(d, duration-pos)*SR)) / SR
            b = np.tanh(1.8*np.sin(2*np.pi*f*t)) * 0.30 * env(len(t), 0.01, 0.4)
            a = int(pos*SR); e = min(a+len(b), n)
            mix[a:e] += b[:e-a]; pos += d

    # 4) Super saw pads con detune ±3 cents + filter sweep lento
    for base in [A3, C4, E4]:
        for cents in [-3, 0, 3]:
            f = base * 2**(cents/1200)
            t = np.arange(n)/SR
            sweep = 0.5 + 0.5*np.sin(2*np.pi*t/max(duration,8) - np.pi/2)
            mix += (2*(t*f % 1) - 1) * 0.018 * sweep

    # 5) Snare + clap en tiempos 2 y 4
    pos = BEAT
    while pos < duration:
        t = np.arange(int(0.12*SR)) / SR
        sn = (np.random.randn(len(t)) * np.exp(-t*30) + np.sin(2*np.pi*190*t)*np.exp(-t*22)) * 0.34
        a = int(pos*SR); e = min(a+len(sn), n)
        mix[a:e] += sn[:e-a]; pos += 2*BEAT

    # 6) White noise riser antes del final (drop en el CTA)
    rd = min(2.5, duration*0.25); rn = int(rd*SR)
    t = np.arange(rn)/SR
    riser = np.random.randn(rn) * (t/rd)**2 * 0.28
    a = n - rn - int(1.2*SR)
    if a > 0: mix[a:a+rn] += riser

    # 7) Zap de impacto en el momento clave (aparición del CTA)
    zp = n - int(1.2*SR)
    if zp > 0:
        t = np.arange(int(0.3*SR))/SR
        zap = np.sin(2*np.pi*(900*np.exp(-t*9))*t) * np.exp(-t*11) * 0.5
        e = min(zp+len(zap), n); mix[zp:e] += zap[:e-zp]

    mix = np.tanh(mix)  # limitador suave
    return (mix / max(1e-9, np.abs(mix).max()) * 0.92 * 32767).astype(np.int16)

if __name__ == "__main__":
    dur, out = float(sys.argv[1]), sys.argv[2]
    data = build(dur)
    with wave.open(out, "w") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(data.tobytes())
    print(f"OK {out} ({dur}s)")
