-- =====================================================
-- ALPHAVISION AI · CALENDARIO DE CONTENIDO (Supabase)
-- Tabla que alimenta el workflow de n8n
-- =====================================================

create table if not exists content_calendar (
  id            uuid primary key default gen_random_uuid(),
  reel_number   int not null,                -- 1..23
  title         text not null,
  format_type   text not null,               -- 'listicle' | 'senal_vivo' | 'pov_origen' | 'educativo' | 'producto' | 'cta'
  account       text not null default 'brand',  -- 'brand' (AlphaVision) | 'personal' (Marc)
  platforms     text[] not null default '{instagram}',  -- {'instagram','linkedin'}
  video_url     text not null,               -- URL pública en Supabase Storage (bucket: reels)
  caption_base  text not null,               -- Hook + cuerpo + CTA base (Claude lo adapta por plataforma)
  hashtags      text default '#Trading #XAUUSD #MRA #IA #WealthIntelligence #AlphaVisionAI',
  publish_date  date not null,
  publish_time  time not null default '12:00',
  status        text not null default 'pending', -- pending | processing | published | error
  ig_media_id   text,
  li_post_id    text,
  error_msg     text,
  needs_rerender boolean default false,      -- true para reel1 y reel12 (precio en vivo)
  created_at    timestamptz default now()
);

create index if not exists idx_calendar_pending
  on content_calendar (status, publish_date, publish_time);

-- =====================================================
-- SEED: 23 reels · 1 diario · empezando por los de
-- mayor save-rate (reel20, reel22, reel13) según el doc
-- =====================================================
-- Cuenta MARCA: señales, Daily Brief, Track Record, Academia, producto
-- Cuenta PERSONAL: POV origen, antes/ahora, 5 cosas que cambié
-- LINKEDIN: solo formatos educativos / historia de fundador / producto B2B

insert into content_calendar (reel_number, title, format_type, account, platforms, video_url, caption_base, publish_date, needs_rerender) values
(20, '5 cosas que cambié',        'listicle',   'personal', '{instagram,linkedin}', 'REEMPLAZAR_URL/reel20.mp4', 'Hace 4 años operaba sin sistema. Estas son las 5 cosas que cambié...', current_date, false),
(22, '6 errores',                 'listicle',   'brand',    '{instagram,linkedin}', 'REEMPLAZAR_URL/reel22.mp4', '6 errores que cometes operando XAU/USD (y cómo los corrige un sistema)...', current_date + 1, false),
(13, 'MRA en 3 pasos',            'educativo',  'brand',    '{instagram,linkedin}', 'REEMPLAZAR_URL/reel13.mp4', 'La estrategia MRA en 3 pasos: Asia forma, Londres rompe, AURA avisa...', current_date + 2, false),
(14, 'Mientras duermes',          'producto',   'brand',    '{instagram}',          'REEMPLAZAR_URL/reel14.mp4', 'De 01:00 a 07:05 la IA vigila el rango de Asia por ti...', current_date + 3, false),
(11, 'Antes / Ahora',             'pov_origen', 'personal', '{instagram}',          'REEMPLAZAR_URL/reel11.mp4', 'Antes: caos, sin journal, entradas por impulso. Ahora: sistema...', current_date + 4, false),
(17, 'Academia MRA',              'educativo',  'brand',    '{instagram,linkedin}', 'REEMPLAZAR_URL/reel17.mp4', '4 conceptos de trading institucional que nadie te enseñó...', current_date + 5, false),
(1,  'Señal MRA en vivo',         'senal_vivo', 'brand',    '{instagram}',          'REEMPLAZAR_URL/reel01.mp4', 'Así se ve una señal MRA confirmada en XAU/USD...', current_date + 6, true),
(19, 'Stats Track Record',        'producto',   'brand',    '{instagram,linkedin}', 'REEMPLAZAR_URL/reel19.mp4', '12 setups. Ratio 1:2. 15 sesiones. 8 alertas. Todo registrado solo...', current_date + 7, false),
(10, 'POV origen',                'pov_origen', 'personal', '{instagram,linkedin}', 'REEMPLAZAR_URL/reel10.mp4', 'POV: llevas 4 años operando manual y decides automatizar tu estrategia...', current_date + 8, false),
(16, 'Scalping MRA',              'educativo',  'brand',    '{instagram}',          'REEMPLAZAR_URL/reel16.mp4', 'Scalping con criterio: los 5 pasos del proceso MRA...', current_date + 9, false),
(5,  'Daily Brief',               'producto',   'brand',    '{instagram,linkedin}', 'REEMPLAZAR_URL/reel05.mp4', 'Cada mañana a las 07:30: macro, eventos y estado del rango de Asia...', current_date + 10, false),
(9,  '3 señales sin sistema',     'listicle',   'brand',    '{instagram}',          'REEMPLAZAR_URL/reel09.mp4', '3 señales de que estás operando sin sistema...', current_date + 11, false),
(21, '7 funciones',               'producto',   'brand',    '{instagram,linkedin}', 'REEMPLAZAR_URL/reel21.mp4', '7 cosas que el sistema hace por ti mientras tú vives...', current_date + 12, false),
(12, 'Oro rompió el rango',       'senal_vivo', 'brand',    '{instagram}',          'REEMPLAZAR_URL/reel12.mp4', 'El oro acaba de romper el rango de Asia. Esto es lo que detectó la IA...', current_date + 13, true),
(18, 'Chat preguntas AURA',       'producto',   'brand',    '{instagram}',          'REEMPLAZAR_URL/reel18.mp4', 'Le pregunté a AURA 3 cosas antes de abrir Londres...', current_date + 14, false),
(23, 'Rutina diaria',             'listicle',   'personal', '{instagram,linkedin}', 'REEMPLAZAR_URL/reel23.mp4', 'Mi rutina de trading de 07:30 al resto del día...', current_date + 15, false),
(15, 'Plan Pro 7 días',           'cta',        'brand',    '{instagram}',          'REEMPLAZAR_URL/reel15.mp4', '7 días gratis. Sin tarjeta. Estas 4 funciones incluidas...', current_date + 16, false),
(6,  'Track Record',              'producto',   'brand',    '{instagram,linkedin}', 'REEMPLAZAR_URL/reel06.mp4', 'De 0 a 47 operaciones registradas automáticamente...', current_date + 17, false),
(8,  'Eventos macro',             'educativo',  'brand',    '{instagram,linkedin}', 'REEMPLAZAR_URL/reel08.mp4', 'Cómo un evento macro puede invalidar tu setup antes de entrar...', current_date + 18, false),
(7,  'Chat IA',                   'producto',   'brand',    '{instagram}',          'REEMPLAZAR_URL/reel07.mp4', 'Una conversación real con AURA sobre el mercado de hoy...', current_date + 19, false),
(2,  'AURA escuchando',           'producto',   'brand',    '{instagram}',          'REEMPLAZAR_URL/reel02.mp4', 'AURA no duerme. Tú sí...', current_date + 20, false),
(3,  'Brand bumper',              'cta',        'brand',    '{instagram}',          'REEMPLAZAR_URL/reel03.mp4', 'AlphaVision AI. Wealth Intelligence...', current_date + 21, false),
(4,  'CTA closer',                'cta',        'brand',    '{instagram}',          'REEMPLAZAR_URL/reel04.mp4', 'Tu estrategia, automatizada. 7 días gratis. Link en bio...', current_date + 22, false);
